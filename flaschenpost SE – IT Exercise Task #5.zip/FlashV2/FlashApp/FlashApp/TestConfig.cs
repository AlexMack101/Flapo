﻿
namespace FlashApp
{
    public static class TestConfig
    {

        public const string BaseAdress = "https://flapotest.blob.core.windows.net";

        public const string RequestUri = "test/ProductData.json";

        public const string Content = "application/json";
    }
}
